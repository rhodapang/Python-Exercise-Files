# 
# Example file for variables
#

# Declare a variable and initialize it



# re-declaring the variable works



# ERROR: variables of different types cannot be combined



# Global vs. local variables in functions


